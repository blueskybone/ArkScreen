package com.godot17.arksc.database.recruit;

public class FloatWindow {
}
