package com.godot17.arksc.utils;

public class ConfManager {

}
