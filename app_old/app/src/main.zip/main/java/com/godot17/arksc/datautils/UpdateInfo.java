package com.godot17.arksc.datautils;

public class UpdateInfo {
    public static String version = "";
    public static String content = "";
    public static String link = "";
}
