package com.godot17.arksc.database;

import java.util.List;

public class NewOpe {
    private List<String> name;
    public void setName(List<String> name){
        this.name = name;
    }
    public List<String> getName(){
        return this.name;
    }
}
