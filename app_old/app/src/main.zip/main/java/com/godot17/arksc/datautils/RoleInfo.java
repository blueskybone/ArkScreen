package com.godot17.arksc.datautils;

public class RoleInfo {
    public String nickName;
    public String channelName;
    public String channelMasterId;
    public String uid;
    public String userInfo;
}
